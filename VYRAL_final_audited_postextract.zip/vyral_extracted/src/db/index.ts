import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import * as schema from "./schema";

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  throw new Error(
    "DATABASE_URL is required. VYRAL runs on PostgreSQL — see .env.example for the expected format " +
      "(e.g. postgres://user:password@localhost:5432/vyral_dev)."
  );
}

const pool = new Pool({ connectionString });

export const db = drizzle(pool, { schema });
export { schema };
export { pool };
