import { randomUUID } from "crypto";
import path from "path";
import fs from "fs/promises";

/**
 * VYRAL media storage abstraction.
 *
 * In production, swap `getStorageProvider()` to return an S3/R2/Supabase
 * implementation of this interface — nothing else in the app should know
 * or care where bytes physically live. The local-disk provider below is
 * for development only: it is NOT suitable for production (no CDN, no
 * durability guarantees across deploys, and files sit next to the app).
 *
 * Access control lives above this layer (see src/app/api/media/[id]/route.ts):
 * this module only stores/serves bytes by key, it doesn't know about
 * ownership or privacy.
 */
export interface StorageProvider {
  /** Persist a buffer, return the storage key to save on the media row. */
  put(key: string, data: Buffer, contentType: string): Promise<void>;
  /** Read a stored object back out. */
  get(key: string): Promise<Buffer | null>;
  /** Remove a stored object (used on deletion / orphan cleanup). */
  delete(key: string): Promise<void>;
  /**
   * True if this provider can hand back its own signed, access-controlled
   * URL (e.g. S3/R2 pre-signed URLs). The local dev provider returns false
   * — for local storage, access control instead happens in our own
   * /api/media/[id] route, which checks ownership/privacy before streaming
   * bytes back.
   */
  canSign: boolean;
  /** Only meaningful when canSign is true. */
  signedUrlFor?(key: string): Promise<string>;
}

const UPLOAD_ROOT = path.join(process.cwd(), ".data", "media");

class LocalDiskProvider implements StorageProvider {
  canSign = false;

  async put(key: string, data: Buffer) {
    const filePath = path.join(UPLOAD_ROOT, key);
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, data);
  }

  async get(key: string) {
    try {
      return await fs.readFile(path.join(UPLOAD_ROOT, key));
    } catch {
      return null;
    }
  }

  async delete(key: string) {
    await fs.rm(path.join(UPLOAD_ROOT, key), { force: true });
  }
}

let provider: StorageProvider | null = null;

export function getStorageProvider(): StorageProvider {
  if (provider) return provider;
  const kind = process.env.STORAGE_PROVIDER ?? "local";
  switch (kind) {
    case "local":
      provider = new LocalDiskProvider();
      break;
    // case "s3": provider = new S3Provider({ ... }); break;
    // case "r2": provider = new R2Provider({ ... }); break;
    // case "supabase": provider = new SupabaseStorageProvider({ ... }); break;
    default:
      throw new Error(
        `Unknown STORAGE_PROVIDER "${kind}". Implement it in src/lib/storage.ts, or set STORAGE_PROVIDER=local for development.`
      );
  }
  return provider;
}

/**
 * The single place that turns a media DB row into a URL the client can
 * load. Every consumer (feed, profile, stories, reels, express, messages)
 * should call this rather than reading media.storageKey directly.
 */
export async function getMediaUrl(mediaRow: { id: string; storageKey: string }): Promise<string> {
  const p = getStorageProvider();
  if (p.canSign && p.signedUrlFor) {
    return p.signedUrlFor(mediaRow.storageKey);
  }
  return `/api/media/${mediaRow.id}`;
}

export function newStorageKey(ownerId: string, originalName: string) {
  const rawExt = path.extname(originalName).slice(0, 10).toLowerCase();
  // Only ever emit a plain ".word" extension — strips path separators,
  // traversal sequences, or anything else smuggled into a client-supplied
  // filename. ownerId is always our own UUID, never client-supplied text.
  const safeExt = /^\.[a-z0-9]{1,9}$/.test(rawExt) ? rawExt : "";
  return `${ownerId}/${randomUUID()}${safeExt}`;
}

export const ALLOWED_MIME_PREFIXES = ["image/", "video/", "audio/"];
export const MAX_UPLOAD_BYTES = 100 * 1024 * 1024; // 100MB

export function kindForMime(mime: string): "image" | "video" | "audio" | null {
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  return null;
}

/**
 * Sniffs the actual file signature rather than trusting the client-supplied
 * Content-Type/extension. Deliberately small and conservative — extend as
 * new formats are supported. Returns null if the bytes don't match any
 * known signature for the claimed kind.
 */
export function sniffMime(buffer: Buffer, claimedMime: string): string | null {
  const sig = buffer.subarray(0, 12);
  const isJpeg = sig[0] === 0xff && sig[1] === 0xd8;
  const isPng = sig[0] === 0x89 && sig[1] === 0x50 && sig[2] === 0x4e && sig[3] === 0x47;
  const isGif = sig.toString("ascii", 0, 3) === "GIF";
  const isWebp = sig.toString("ascii", 0, 4) === "RIFF" && sig.toString("ascii", 8, 12) === "WEBP";
  const isMp4 = sig.toString("ascii", 4, 8) === "ftyp";
  const isWebm = sig[0] === 0x1a && sig[1] === 0x45 && sig[2] === 0xdf && sig[3] === 0xa3;
  const isMp3 = sig.toString("ascii", 0, 3) === "ID3" || (sig[0] === 0xff && (sig[1] & 0xe0) === 0xe0);
  const isWav = sig.toString("ascii", 0, 4) === "RIFF" && sig.toString("ascii", 8, 12) === "WAVE";
  const isOgg = sig.toString("ascii", 0, 4) === "OggS";

  const detected =
    (isJpeg && "image/jpeg") ||
    (isPng && "image/png") ||
    (isGif && "image/gif") ||
    (isWebp && "image/webp") ||
    (isMp4 && "video/mp4") ||
    (isWebm && "video/webm") ||
    (isOgg && "audio/ogg") ||
    (isWav && "audio/wav") ||
    (isMp3 && "audio/mpeg") ||
    null;

  if (!detected) return null;
  // The broad kind (image/video/audio) must match what was claimed, even if
  // the exact subtype differs (e.g. claimed "image/jpg" vs sniffed "image/jpeg").
  if (kindForMime(detected) !== kindForMime(claimedMime)) return null;
  return detected;
}
